'use client'

import { useState } from 'react'

type CRPMLogoProps = {
  ticker: string
  size?: 'sm' | 'md' | 'lg'
}

const sizes = {
  sm: 'h-8 w-8',
  md: 'h-11 w-11',
  lg: 'h-12 w-12',
}

const imageSizes = {
  sm: 'h-6 w-6',
  md: 'h-8 w-8',
  lg: 'h-10 w-10',
}

export default function CRPMLogo({
  ticker,
  size = 'lg',
}: CRPMLogoProps) {
  const cleanTicker = String(ticker || '').toUpperCase()

  const [fallback, setFallback] = useState(false)

  const logoUrl = `https://assets.parqet.com/logos/symbol/${cleanTicker}`

  return (
    <div
      className={`
        flex shrink-0 items-center justify-center
        overflow-hidden rounded-lg
        border border-[var(--crpm-border)]
        bg-white
        ${sizes[size]}
      `}
    >
      {!fallback ? (
        <img
          src={logoUrl}
          alt={`${cleanTicker} logo`}
          className={`object-contain ${imageSizes[size]}`}
          onError={() => setFallback(true)}
        />
      ) : (
        <span className="text-sm font-black text-zinc-900">
          {cleanTicker.slice(0, 1)}
        </span>
      )}
    </div>
  )
}